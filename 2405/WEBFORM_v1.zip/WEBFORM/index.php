<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap-4.4.1.css" rel="stylesheet">
    <style>
        .wrapper {
            width: 650;
            margin: 0 auto;
        }
        
        .page-header h2 {
            margin-top: 0;
        }
        
        table tr td:last-child a {
            margin-right: 15px;
        }
    </style>


</head>

<body>
    <!-- body code goes here -->
    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header clearfix">
                        <h2 class="pull-left">Employee Details</h2>
                        <a href="create.php" class="btn btn-success">Add New Employee</a>
                        <p>  </p>
                    </div>
                    <?php
                    require_once "config.php";
                    $sql = "SELECT * FROM employees";
                    if($result = mysqli_query($link,$sql)){
                        if(mysqli_num_rows($result)>0){
                            echo "<table class='table table-bordered table-striped'>";
                            echo "<thead>";
                            echo "<tr>";
                            echo "<th>#</th>";
                            echo "<th>Name</th>";
                            echo "<th>Address</th>";
                            echo "<th>Salary</th>";
                            echo "<th>Action</th>";
                            echo "</tr>";
                            echo "</thead>";
                            echo "<tbody>";
                            while($row = mysqli_fetch_array($result)){
                                echo "<tr>";
                                echo "<td>".$row['id']."</td>";
                                echo "<td>".$row['name']."</td>";
                                echo "<td>".$row['address']."</td>";
                                echo "<td>".$row['salary']."</td>";
                                echo "<td>";
                                echo "<a href='read.php?id=".$row['id']."' title='View Record' data-toggle='tooltip'><span class='glyphicon glypicon-eye-open'></span></a>";
                                echo "<a href='update.php?id=".$row['id']."' title='Update Record' data-toggle='tooltip'><span class='glyphicon glypicon-eye-open'></span></a>";
                                echo "<a href='delete.php?id=".$row['id']."' title='Delete Record' data-toggle='tooltip'><span class='glyphicon glypicon-eye-open'></span></a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                            echo "</tbody>";
                            echo "</table>";
                            mysqli_free_result($result);
                        }
                        else{
                            echo "<p class='lead'><em>No records were found.</em></p>";
                        }
                    }
                    else{
                        echo "ERROR: Could not able to execute $sql.";
                    }
                    ?>
                </div>
            </div>
        </div>


    </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery-3.4.1.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap-4.4.1.js"></script>


    <script>
        $(document).ready(function() {
            $('[data-toggle = "tooltip"]').tooltip();
        });
    </script>
</body>

</html>